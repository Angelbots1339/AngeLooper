package org.usfirst.frc.team1339.utils;

public class HardwareAdapter{
	
	public HardwareAdapter(){
		
	}
	
	public void checkTriggers(){
		/*
		 * This is where you put any whenPressed() or toggle() things. eg:
		 * AButton.whenPressed(new DriveShooter);
		 * or
		 * XButton.toggle(new TankDrive(), new ArcadeDrive());
		 */
	}
}
