package org.usfirst.frc.team1339.commands;

import org.usfirst.frc.team1339.base.CommandBase;

public class ExampleCommand extends CommandBase{
	
	public ExampleCommand(){
		/*
		 * This is where you would put requires(), setRunSpeed(), and setTimeout(). eg:
		 * requires(Robot.Chassis);
		 * setRunSpeed(0.05);
		 * setTimeout(5);
		 */
	}
	
	protected void init(){
		
	}
	
	public void execute(){
		
	}
	
	public boolean isFinished(){
		return false;
	}
	
	protected void end(){
		
	}
	
	protected void interrupted(){
		
	}
}
