package org.usfirst.frc.team1339.subsystems;

import org.usfirst.frc.team1339.base.SubsystemBase;

public class ExampleSubsystem extends SubsystemBase{
	
	public ExampleSubsystem(){
	}
	
	public void initDefaultCommand(){
		/*
		 * This is where you set the default command if you have one. eg:
		 * setDefaultCommand(new DriveChassis());
		 */
	}
}
